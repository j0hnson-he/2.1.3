package org.pltw.examples.makingclasses;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Arithmetic testArithmetic = new Arithmetic();
        System.out.println(testArithmetic);
        TaxArithmetic derp = new TaxArithmetic(5, 10); //showing off super class
        derp.calculateTax(5, 5);
        derp.add(4, 10); // using add() method
    }

}